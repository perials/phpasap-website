<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Welcome to PHPasap</title>
    </head>
    <body>
        <?php echo $content; ?>
    </body>
</html>
