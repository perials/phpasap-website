<?php

return [

    'debug' => true,
    
];

?>