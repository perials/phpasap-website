<?php

return [

    //set the from address here
    'from' => '',
    
    //smpt configurations
    'use_smtp' => false, // set this to true if you wish to use smtp
    'smtp_host' => '',
    'smtp_username' => '',
    'smtp_password' => '',
    'smtp_encryption' => '',
    'smtp_port' => '',
    
    'is_html' => true

];