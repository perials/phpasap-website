<div style="text-align: center">
    <h2>Oops!</h2>
    <h3>404- Not found</h3>
</div>