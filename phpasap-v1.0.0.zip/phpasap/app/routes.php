<?php
Route::add('GET', '/', 'Welcome_Controller@index');