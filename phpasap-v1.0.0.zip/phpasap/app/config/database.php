<?php
return [
    
    'hostname' => '',
    'database' => '',
    'username' => '',
    'password' => '',
            
];